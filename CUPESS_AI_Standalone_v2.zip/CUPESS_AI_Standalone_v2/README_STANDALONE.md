# CUPESS AI Standalone v2.0

This package is an Android/Chaquopy project. The APK starts the Python Flask backend itself, so Termux is NOT required when the installed app runs.

## API setup
1. Install the generated APK.
2. Open CUPESS AI.
3. Tap **API Settings**.
4. Paste your own OpenRouter API key.
5. Tap **Connect API**.

The package intentionally contains no real API key.

## Build on Android/Termux
The Android module uses Chaquopy 17, Python 3.13, AGP 9.2 and arm64-v8a. From the `android` directory, use the Gradle installation already configured on the phone:

```bash
gradle :app:assembleDebug
```

The APK will be at `android/app/build/outputs/apk/debug/app-debug.apk`.

## Important
This ZIP is the complete source project, not a prebuilt APK. A build environment must download Gradle/Android/Chaquopy dependencies, so it cannot be truthfully advertised as an already-tested APK from this environment.
