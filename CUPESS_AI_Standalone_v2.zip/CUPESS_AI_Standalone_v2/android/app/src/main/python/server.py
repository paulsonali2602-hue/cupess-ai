import threading
from cupess.app import create_app

_app = None
_started = False
_lock = threading.Lock()

def start_server():
    global _app, _started
    with _lock:
        if _started:
            return
        _app = create_app()
        _started = True
    threading.Thread(
        target=lambda: _app.run(host="127.0.0.1", port=5000, debug=False, use_reloader=False),
        daemon=True
    ).start()
