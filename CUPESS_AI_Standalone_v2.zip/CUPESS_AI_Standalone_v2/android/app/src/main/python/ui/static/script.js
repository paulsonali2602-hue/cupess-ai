const $=s=>document.querySelector(s);
const chat=$('#chat'),welcome=$('#welcome'),form=$('#form'),message=$('#message'),send=$('#sendBtn'),status=$('#connectionText'),model=$('#modelText'),dot=$('#dot'),modeLabel=$('#modeLabel'),sidebar=$('#sidebar');
let currentMode='chat';

async function checkStatus(){
 try{const d=await (await fetch('/api/status')).json();
  status.textContent=d.api_configured?'Connected':'API key missing';
  model.textContent=d.api_configured?'CUPESS online':'Waiting for API';
  dot.style.background=d.api_configured?'#42d392':'#ffb84a';
 }catch(e){status.textContent='Offline';dot.style.background='#ff6b7a'}
}
function addMsg(text,type){
 const row=document.createElement('div'); row.className='msg '+type;
 row.innerHTML='<div class="avatar">'+(type==='user'?'You':'C')+'</div><div class="bubble"></div>';
 row.querySelector('.bubble').textContent=text; chat.appendChild(row);
 $('.content')?.scrollTo({top:document.body.scrollHeight,behavior:'smooth'}); return row;
}
function addEvent(stage,mdl){
 const e=document.createElement('div');e.className='event';e.innerHTML='<b>'+stage+'</b> · '+(mdl||'');chat.appendChild(e);
}
async function sendMessage(){
 const text=message.value.trim(); if(!text)return;
 welcome.style.display='none'; addMsg(text,'user'); message.value=''; resize();
 const thinking=addMsg('Thinking…','bot'); send.disabled=true;
 try{
  const r=await fetch('/api/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,mode:currentMode})});
  const d=await r.json(); thinking.remove();
  if(d.error){addMsg('Error: '+d.error,'bot'); toast(d.error)}
  else{addMsg(d.answer||'Done.','bot');(d.events||[]).forEach(e=>addEvent(e.stage||e.mode,e.model))}
 }catch(e){thinking.remove();addMsg('Connection error: '+e,'bot')}
 send.disabled=false; message.focus();
}
function resize(){message.style.height='auto';message.style.height=Math.min(message.scrollHeight,140)+'px'}
function toast(t){const x=$('#toast');x.textContent=t;x.classList.add('show');setTimeout(()=>x.classList.remove('show'),2500)}
form.addEventListener('submit',e=>{e.preventDefault();sendMessage()});
message.addEventListener('input',resize);
message.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();sendMessage()}});
document.querySelectorAll('.mode').forEach(b=>b.onclick=()=>{document.querySelectorAll('.mode').forEach(x=>x.classList.remove('active'));b.classList.add('active');currentMode=b.dataset.mode;modeLabel.textContent=currentMode==='agent'?'Coding Agent mode':'Chat mode'});
document.querySelectorAll('.suggest').forEach(b=>b.onclick=()=>{message.value=b.dataset.prompt;resize();message.focus()});
$('#newChat').onclick=()=>{chat.innerHTML='';welcome.style.display='block';toast('New chat')};
$('#menuBtn').onclick=()=>sidebar.classList.toggle('open');
$('#settingsBtn').onclick=()=>toast('Settings panel coming next');
$('#themeBtn').onclick=()=>toast('Dark theme is active');
$('#voiceBtn').onclick=()=>toast('Voice input will be connected in the next build');
checkStatus();
