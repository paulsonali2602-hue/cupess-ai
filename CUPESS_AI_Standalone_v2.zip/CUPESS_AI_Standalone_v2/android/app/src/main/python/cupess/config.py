import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

def _workspace_dir():
    # Chaquopy extracts packaged Python files to a read-only location.
    # Use the app-private HOME directory for writable workspace data.
    home = Path(os.environ.get("HOME", str(BASE_DIR)))
    name = os.getenv("WORKSPACE_DIR", "workspace").strip() or "workspace"
    return (home / name).resolve()

class Config:
    API_KEY = os.getenv("OPENROUTER_API_KEY", "").strip()
    MODEL = os.getenv("OPENROUTER_MODEL", "cohere/north-mini-code:free").strip()
    FALLBACK_MODELS = [x.strip() for x in os.getenv("OPENROUTER_FALLBACK_MODELS", "").split(",") if x.strip()]
    WORKSPACE_DIR = _workspace_dir()
    MAX_DEBUG_RETRIES = int(os.getenv("MAX_DEBUG_RETRIES", "3"))
    API_URL = "https://openrouter.ai/api/v1/chat/completions"

Config.WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)

def configure(api_key=None, model=None, fallback_models=None):
    """Update runtime configuration without requiring a packaged .env file."""
    if api_key is not None:
        Config.API_KEY = str(api_key).strip()
        os.environ["OPENROUTER_API_KEY"] = Config.API_KEY
    if model is not None and str(model).strip():
        Config.MODEL = str(model).strip()
        os.environ["OPENROUTER_MODEL"] = Config.MODEL
    if fallback_models is not None:
        Config.FALLBACK_MODELS = [str(x).strip() for x in fallback_models if str(x).strip()]
    Config.WORKSPACE_DIR = _workspace_dir()
    Config.WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
    return Config
