from pathlib import Path
from flask import Flask, request, jsonify, render_template
from .agent import CupessAgent
from .config import Config, configure

def create_app():
    base_dir = Path(__file__).resolve().parent.parent
    app = Flask(__name__, template_folder=str(base_dir / "ui"), static_folder=str(base_dir / "ui" / "static"))
    agent = CupessAgent()

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/status")
    def status():
        return jsonify({
            "name": "CUPESS AI",
            "version": "2.0.0",
            "api_configured": bool(Config.API_KEY and Config.API_KEY != "YOUR_OPENROUTER_KEY_HERE"),
            "model": Config.MODEL,
        })

    @app.post("/api/configure")
    def configure_api():
        d = request.get_json(silent=True) or {}
        key = str(d.get("api_key", "")).strip()
        model = str(d.get("model", "")).strip() or Config.MODEL
        if not key:
            return jsonify({"error": "API key is empty"}), 400
        configure(key, model)
        return jsonify({"ok": True, "api_configured": True, "model": Config.MODEL})

    @app.post("/api/chat")
    def chat():
        d = request.get_json(silent=True) or {}
        text = str(d.get("message", "")).strip()
        if not text:
            return jsonify({"error": "Message is empty"}), 400
        try:
            if d.get("mode") == "agent":
                a, e = agent.run_task(text)
            else:
                a, m = agent.chat(text); e = [m]
            return jsonify({"answer": a, "events": e})
        except Exception as ex:
            return jsonify({"error": str(ex)}), 500

    return app
