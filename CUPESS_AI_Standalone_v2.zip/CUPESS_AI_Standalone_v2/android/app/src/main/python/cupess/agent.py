import json, re
from .openrouter import OpenRouter
from .tools import Workspace
from .config import Config

SYSTEM = """You are CUPESS AI, a friendly and confident coding companion.
Your name is CUPESS AI. The underlying provider is infrastructure only; never introduce
yourself as OpenRouter, Cohere, or another model. Do not claim to be human or have real
feelings. Be warm, natural, encouraging, and occasionally playful. Keep simple chat concise.
For coding tasks, be decisive, practical, and honest about what was actually created/tested."""

def extract_json(text):
    text=(text or "").strip()
    for candidate in (text, re.sub(r"```(?:json)?|```","",text,flags=re.I).strip()):
        try: return json.loads(candidate)
        except Exception: pass
    start=text.find("{")
    while start >= 0:
        depth=0; quote=False; esc=False
        for i in range(start,len(text)):
            c=text[i]
            if quote:
                if esc: esc=False
                elif c=="\\": esc=True
                elif c=='"': quote=False
            elif c=='"': quote=True
            elif c=="{": depth+=1
            elif c=="}":
                depth-=1
                if depth==0:
                    try: return json.loads(text[start:i+1])
                    except Exception: break
        start=text.find("{",start+1)
    return None

class CupessAgent:
    def __init__(self):
        self.llm=OpenRouter()
        self.ws=Workspace(Config.WORKSPACE_DIR)

    def chat(self,text):
        r=self.llm.chat([
            {"role":"system","content":SYSTEM},
            {"role":"user","content":text}
        ])
        return r["text"],{"mode":"chat","label":"CUPESS AI"}

    def plan(self,task):
        r=self.llm.chat([
            {"role":"system","content":SYSTEM+"""
You are CUPESS's planning stage. Return ONLY valid JSON:
{"goal":"...","steps":["..."],"files":["..."],"tests":["..."]}
"""},
            {"role":"user","content":task}
        ],max_tokens=2500)
        obj=extract_json(r["text"])
        if not isinstance(obj,dict):
            obj={"goal":task,"steps":["Analyze","Implement","Review"],"files":[],"tests":[]}
        return obj

    def run_task(self,task):
        events=[{"stage":"Planner","label":"CUPESS AI"}]
        plan=self.plan(task)
        r=self.llm.chat([
            {"role":"system","content":SYSTEM+"""
You are CUPESS's coding stage. Return ONLY valid JSON:
{"files":[{"path":"relative/path","content":"complete file contents"}]}
No markdown. Only workspace-relative paths.
"""},
            {"role":"user","content":f"Task: {task}\nPlan: {json.dumps(plan)}\nWorkspace: {self.ws.tree()}"}
        ],max_tokens=7000)
        obj=extract_json(r["text"])
        if not isinstance(obj,dict) or not isinstance(obj.get("files"),list):
            repair=self.llm.chat([
                {"role":"system","content":'Return ONLY valid JSON in this exact shape: {"files":[{"path":"relative/path","content":"complete content"}]}. Preserve the generated code.'},
                {"role":"user","content":r["text"]}
            ],max_tokens=7500)
            obj=extract_json(repair["text"])
        if not isinstance(obj,dict) or not isinstance(obj.get("files"),list):
            events.append({"stage":"Coder","label":"CUPESS AI","status":"retry-needed"})
            return "I couldn't safely parse the generated files, so I stopped before writing broken code. Try again and I'll recover.",events
        written=[]
        for f in obj["files"]:
            if isinstance(f,dict) and "path" in f and "content" in f:
                try: written.append(self.ws.write(str(f["path"]),str(f["content"])))
                except ValueError: pass
        events.append({"stage":"Coder","label":"CUPESS AI","files":written})
        review=self.llm.chat([
            {"role":"system","content":SYSTEM+"\nYou are CUPESS's reviewer. Start with PASS if the result looks reasonable; otherwise list concrete issues."},
            {"role":"user","content":f"Task: {task}\nFiles: {written}\nWorkspace: {self.ws.tree()}"}
        ],max_tokens=2000)
        events.append({"stage":"Reviewer","label":"CUPESS AI","status":"passed" if "PASS" in review["text"].upper() else "reviewed"})
        return f"Done! I built the requested change.\n\nFiles: {', '.join(written) if written else 'none'}\nI also completed a review pass.",events
