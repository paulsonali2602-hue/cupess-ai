package com.cupess.ai;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.chaquo.python.AndroidPlatform;
import com.chaquo.python.Python;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String PREFS = "cupess_settings";
    private static final String KEY_API = "api_key";
    private static final String KEY_MODEL = "model";
    private final Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        webView.setWebViewClient(new WebViewClient());

        if (!Python.isStarted()) {
            Python.start(new AndroidPlatform(this));
        }

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String apiKey = p.getString(KEY_API, "");
        String model = p.getString(KEY_MODEL, "cohere/north-mini-code:free");

        Python py = Python.getInstance();
        py.getModule("server").callAttr("start_server");

        // The web UI stores settings itself too. Inject the native saved values
        // through a small URL-safe JS call once the local server is ready.
        waitForServer(apiKey, model, 0);
    }

    private void waitForServer(String apiKey, String model, int attempt) {
        if (attempt > 20) {
            Toast.makeText(this, "CUPESS server did not start", Toast.LENGTH_LONG).show();
            return;
        }
        handler.postDelayed(() -> {
            webView.loadUrl("http://127.0.0.1:5000");
            String safeKey = js(apiKey);
            String safeModel = js(model);
            webView.postDelayed(() -> webView.evaluateJavascript(
                    "window.CUPESS_NATIVE_CONFIG && window.CUPESS_NATIVE_CONFIG(" + safeKey + "," + safeModel + ")", null), 900);
        }, 500 + attempt * 250L);
    }

    private String js(String s) {
        if (s == null) return """";
        return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ").replace("\r", " ") + "\"";
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
